git clone https://github.com/Rapptz/discord.py
cd discord.py
su
alpine
apt install libffi-dev libnacl-dev python3-dev